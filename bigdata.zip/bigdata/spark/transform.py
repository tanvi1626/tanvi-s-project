from pyspark.sql import SparkSession
from pyspark.ml.feature import StringIndexer, VectorAssembler

spark = SparkSession.builder.appName("DataWrangling").getOrCreate()

df = spark.read.option("header", True).csv("/data/2019-Oct.csv", inferSchema=True)

df = df.filter(df.event_type == 'purchase').dropna(subset=["brand", "price"])

category_indexer = StringIndexer(inputCol="category_code", outputCol="category_index")
brand_indexer = StringIndexer(inputCol="brand", outputCol="brand_index")

df = category_indexer.fit(df).transform(df)
df = brand_indexer.fit(df).transform(df)

df = df.withColumn("label", df.price)

assembler = VectorAssembler(
    inputCols=["category_index", "brand_index"],
    outputCol="features"
)
df = assembler.transform(df)

df.select("features", "label").write.parquet("/output/processed_data.parquet")
