from pyspark.sql import SparkSession
from pyspark.ml.classification import RandomForestRegressor
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml import Pipeline
import matplotlib.pyplot as plt

spark = SparkSession.builder.appName("MLModel").getOrCreate()
df = spark.read.parquet("/output/processed_data.parquet")

train_data, test_data = df.randomSplit([0.8, 0.2], seed=42)

rf = RandomForestRegressor(labelCol="label", featuresCol="features", numTrees=50, maxBins=2048)

model = rf.fit(train_data)
predictions = model.transform(test_data)

evaluator = RegressionEvaluator(labelCol="label", predictionCol="prediction", metricName="rmse")
rmse = evaluator.evaluate(predictions)
print(f"Test RMSE: {rmse}")
