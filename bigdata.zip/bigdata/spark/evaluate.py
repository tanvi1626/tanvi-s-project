from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os

# Create output folder if not exists
os.makedirs("data", exist_ok=True)

# === 1. Evaluation Metrics ===
binary_eval = BinaryClassificationEvaluator(labelCol="label", metricName="areaUnderROC")
auc = binary_eval.evaluate(predictions)

multi_eval = MulticlassClassificationEvaluator(labelCol="label", metricName="f1")
f1 = multi_eval.evaluate(predictions)

precision = MulticlassClassificationEvaluator(labelCol="label", metricName="precisionByLabel").evaluate(predictions)
recall = MulticlassClassificationEvaluator(labelCol="label", metricName="recallByLabel").evaluate(predictions)

print(f"AUC: {auc:.4f}")
print(f"F1-Score: {f1:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")

# Save metrics to file
with open("data/model_metrics.txt", "w") as f:
    f.write(f"AUC: {auc:.4f}\n")
    f.write(f"F1-Score: {f1:.4f}\n")
    f.write(f"Precision: {precision:.4f}\n")
    f.write(f"Recall: {recall:.4f}\n")

# === 2. Confusion Matrix Plot ===
pandas_pred = predictions.select("label", "prediction").toPandas()
conf_mat = pd.crosstab(pandas_pred['label'], pandas_pred['prediction'], rownames=['Actual'], colnames=['Predicted'])

plt.figure(figsize=(6, 4))
sns.heatmap(conf_mat, annot=True, fmt='d', cmap="YlGnBu")
plt.title("Confusion Matrix")
plt.tight_layout()
plt.savefig("data/confusion_matrix.png")
plt.close()

# === 3. Feature Importance Plot ===
from pyspark.ml.classification import RandomForestClassificationModel

if isinstance(model, RandomForestClassificationModel):
    importances = model.featureImportances.toArray()
    feature_names = ["category_code", "brand"]  # Adjust based on features used
    plt.figure(figsize=(6, 4))
    plt.barh(feature_names, importances)
    plt.xlabel("Feature Importance")
    plt.title("Random Forest Feature Importances")
    plt.tight_layout()
    plt.savefig("data/feature_importance.png")
    plt.close()
else:
    print("Model does not support feature importances.")
