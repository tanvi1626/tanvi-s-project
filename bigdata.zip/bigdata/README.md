📊 E-Commerce User Events Analysis
This project analyzes e-commerce user behavior using Hive, PySpark, and applies a machine learning model to predict user actions based on event data.

✅ Project Structure
kotlin
Copy code
bigdata_task/
├── data/
│   ├── 2019-Oct.csv
│   ├── confusion_matrix.png
│   ├── feature_importance.png
│   └── model_metrics.txt
├── scripts/
│   ├── data_preprocessing.py
│   ├── ml_pipeline.py
│   └── evaluate_and_visualize.py
├── docker-compose.yml
└── README.md
🔧 Tools & Technologies
Hive + Hadoop (for data storage and HiveQL analysis)

PySpark (data processing and ML)

Scikit-learn-like MLlib (Random Forest)

Matplotlib + Seaborn (visualization)

Docker (containerized environment)

🧹 Task 1: Data Ingestion
Loaded 2019-Oct.csv into Hive as a partitioned table ecommerce_user_events

Partitioned by year and month

🔍 Task 2: Exploratory Analysis (HiveQL)
Sample Hive queries:

sql
Copy code
-- Top brands by revenue
SELECT brand, SUM(price) AS revenue
FROM ecommerce_user_events
WHERE event_type = 'purchase'
GROUP BY brand
ORDER BY revenue DESC
LIMIT 5;
⚙️ Task 3: Data Processing (PySpark)
Cleaned null/missing fields

Converted categorical fields using StringIndexer and VectorAssembler

Transformed data to be ML-ready

🤖 Task 4: Machine Learning
Model: Random Forest Classifier (from MLlib)

Split: 80% train, 20% test

Evaluation:

AUC, Precision, Recall, F1-score

Plots: Confusion Matrix, Feature Importance

📈 Evaluation Outputs
Located in /data/:

confusion_matrix.png

feature_importance.png

model_metrics.txt

💡 Insights & Conclusion
The model helps identify which users are more likely to purchase based on their browsing behavior. This can assist marketing teams in user targeting and retention strategies.